(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ephemer:reactive-datatables'] = {};

})();

//# sourceMappingURL=ephemer_reactive-datatables.js.map
