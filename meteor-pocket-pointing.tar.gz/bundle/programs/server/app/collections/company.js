(function(){Companies = new Mongo.Collection("companies");

})();
