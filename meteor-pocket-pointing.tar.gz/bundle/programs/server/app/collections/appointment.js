(function(){Appointments = new Mongo.Collection("appointments");

})();
