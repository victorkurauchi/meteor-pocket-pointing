(function(){Employees = new Mongo.Collection("employees");

})();
