(function(){Projects = new Mongo.Collection("projects");

})();
