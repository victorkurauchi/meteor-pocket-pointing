(function () {

/* Imports */
var _ = Package.underscore._;
var DDP = Package.ddp.DDP;
var DDPServer = Package.ddp.DDPServer;
var Meteor = Package.meteor.Meteor;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var JsonRoutes = Package['simple:json-routes'].JsonRoutes;
var EJSON = Package.ejson.EJSON;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

/* Package-scope variables */
var HttpConnection, HttpSubscription, paths, pathInfo;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/simple:rest/http-connection.js                                                               //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
// Simulate a DDP connection from HTTP request                                                           // 1
                                                                                                         // 2
HttpConnection = function () {                                                                           // 3
  // no-op now                                                                                           // 4
};                                                                                                       // 5
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/simple:rest/http-subscription.js                                                             //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
var EventEmitter = Npm.require("events").EventEmitter;                                                   // 1
                                                                                                         // 2
// This file describes something like Subscription in                                                    // 3
// meteor/meteor/packages/ddp/livedata_server.js, but instead of sending                                 // 4
// over a socket it puts together an HTTP response                                                       // 5
HttpSubscription = function (options) {                                                                  // 6
  // Object where the keys are collection names, and then the keys are _ids                              // 7
  this.responseData = {};                                                                                // 8
                                                                                                         // 9
  this.connection = new HttpConnection(options.request);                                                 // 10
  this.userId = options.userId;                                                                          // 11
};                                                                                                       // 12
                                                                                                         // 13
// So that we can listen to ready event in a reasonable way                                              // 14
Meteor._inherits(HttpSubscription, EventEmitter);                                                        // 15
                                                                                                         // 16
_.extend(HttpSubscription.prototype, {                                                                   // 17
  added: function (collection, id, fields) {                                                             // 18
    var self = this;                                                                                     // 19
                                                                                                         // 20
    check(collection, String);                                                                           // 21
    check(id, String);                                                                                   // 22
                                                                                                         // 23
    self._ensureCollectionInRes(collection);                                                             // 24
                                                                                                         // 25
    // Make sure to ignore the _id in fields                                                             // 26
    var addedDocument = _.extend({_id: id}, _.omit(fields, "_id"));                                      // 27
    self.responseData[collection][id] = addedDocument;                                                   // 28
  },                                                                                                     // 29
  changed: function (collection, id, fields) {                                                           // 30
    var self = this;                                                                                     // 31
                                                                                                         // 32
    check(collection, String);                                                                           // 33
    check(id, String);                                                                                   // 34
                                                                                                         // 35
    self._ensureCollectionInRes(collection);                                                             // 36
                                                                                                         // 37
    var existingDocument = this.responseData[collection][id];                                            // 38
    var fieldsNoId = _.omit(fields, "_id");                                                              // 39
    _.extend(existingDocument, fieldsNoId);                                                              // 40
                                                                                                         // 41
    // Delete all keys that were undefined in fields (except _id)                                        // 42
    _.each(fields, function (value, key) {                                                               // 43
      if (value === undefined) {                                                                         // 44
        delete existingDocument[key];                                                                    // 45
      }                                                                                                  // 46
    });                                                                                                  // 47
  },                                                                                                     // 48
  removed: function (collection, id) {                                                                   // 49
    var self = this;                                                                                     // 50
                                                                                                         // 51
    check(collection, String);                                                                           // 52
    check(id, String);                                                                                   // 53
                                                                                                         // 54
    self._ensureCollectionInRes(collection);                                                             // 55
                                                                                                         // 56
    delete self.responseData[collection][id];                                                            // 57
                                                                                                         // 58
    if (_.isEmpty(self.responseData[collection])) {                                                      // 59
      delete self.responseData[collection];                                                              // 60
    }                                                                                                    // 61
  },                                                                                                     // 62
  ready: function () {                                                                                   // 63
    this.emit("ready", this._generateResponse());                                                        // 64
  },                                                                                                     // 65
  onStop: function () {                                                                                  // 66
    // no-op in HTTP                                                                                     // 67
  },                                                                                                     // 68
  error: function (error) {                                                                              // 69
    throw error;                                                                                         // 70
  },                                                                                                     // 71
  _ensureCollectionInRes: function (collection) {                                                        // 72
    this.responseData[collection] = this.responseData[collection] || {};                                 // 73
  },                                                                                                     // 74
  _generateResponse: function () {                                                                       // 75
    var output = {};                                                                                     // 76
                                                                                                         // 77
    _.each(this.responseData, function (documents, collectionName) {                                     // 78
      output[collectionName] = _.values(documents);                                                      // 79
    });                                                                                                  // 80
                                                                                                         // 81
    return output;                                                                                       // 82
  }                                                                                                      // 83
});                                                                                                      // 84
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/simple:rest/rest.js                                                                          //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
var oldPublish = Meteor.publish;                                                                         // 1
                                                                                                         // 2
Meteor.publish = function (name, handler, options) {                                                     // 3
  options = options || {};                                                                               // 4
                                                                                                         // 5
  var httpOptionKeys = [                                                                                 // 6
    "url",                                                                                               // 7
    "getArgsFromRequest",                                                                                // 8
    "httpMethod"                                                                                         // 9
  ];                                                                                                     // 10
                                                                                                         // 11
  var httpOptions = _.pick(options, httpOptionKeys);                                                     // 12
  var ddpOptions = _.omit(options, httpOptionKeys);                                                      // 13
                                                                                                         // 14
  // Register DDP publication                                                                            // 15
  oldPublish(name, handler, ddpOptions);                                                                 // 16
                                                                                                         // 17
  _.defaults(httpOptions, {                                                                              // 18
    url: "publications/" + name,                                                                         // 19
    getArgsFromRequest: defaultGetArgsFromRequest,                                                       // 20
    httpMethod: "get"                                                                                    // 21
  });                                                                                                    // 22
                                                                                                         // 23
  JsonRoutes.add(httpOptions.httpMethod, httpOptions.url, function (req, res) {                          // 24
    catchAndReportErrors(httpOptions.url, res, function () {                                             // 25
      var userId = getUserIdFromRequest(req);                                                            // 26
                                                                                                         // 27
      var httpSubscription = new HttpSubscription({                                                      // 28
        request: req,                                                                                    // 29
        userId: userId                                                                                   // 30
      });                                                                                                // 31
                                                                                                         // 32
      httpSubscription.on("ready", function (response) {                                                 // 33
        JsonRoutes.sendResult(res, 200, response);                                                       // 34
      });                                                                                                // 35
                                                                                                         // 36
      var handlerArgs = httpOptions.getArgsFromRequest(req);                                             // 37
                                                                                                         // 38
      var handlerReturn = handler.apply(httpSubscription, handlerArgs);                                  // 39
                                                                                                         // 40
      // Fast track for publishing cursors - we don't even need livequery here,                          // 41
      // just making a normal DB query                                                                   // 42
      if (handlerReturn && handlerReturn._publishCursor) {                                               // 43
        httpPublishCursor(handlerReturn, httpSubscription);                                              // 44
        httpSubscription.ready();                                                                        // 45
      } else if (handlerReturn && _.isArray(handlerReturn)) {                                            // 46
        // We don't need to run the checks to see if the cursors overlap and stuff                       // 47
        // because calling Meteor.publish will do that for us :]                                         // 48
        _.each(handlerReturn, function (cursor) {                                                        // 49
          httpPublishCursor(cursor, httpSubscription);                                                   // 50
        });                                                                                              // 51
                                                                                                         // 52
        httpSubscription.ready();                                                                        // 53
      }                                                                                                  // 54
    });                                                                                                  // 55
  });                                                                                                    // 56
};                                                                                                       // 57
                                                                                                         // 58
var oldMethods = Object.getPrototypeOf(Meteor.server).methods;                                           // 59
Meteor.method = function (name, handler, options) {                                                      // 60
  options = options || {};                                                                               // 61
                                                                                                         // 62
  _.defaults(options, {                                                                                  // 63
    url: "methods/" + name,                                                                              // 64
    getArgsFromRequest: defaultGetArgsFromRequest,                                                       // 65
    httpMethod: "post"                                                                                   // 66
  });                                                                                                    // 67
                                                                                                         // 68
  var methodMap = {};                                                                                    // 69
  methodMap[name] = handler;                                                                             // 70
  oldMethods.call(Meteor.server, methodMap);                                                             // 71
                                                                                                         // 72
  // This is a default collection mutation method, do some special things to                             // 73
  // make it more RESTful                                                                                // 74
  if (insideDefineMutationMethods) {                                                                     // 75
    var collectionName = name.split("/")[1];                                                             // 76
    var modifier = name.split("/")[2];                                                                   // 77
                                                                                                         // 78
    var collectionUrl = "/" + collectionName;                                                            // 79
    var itemUrl = "/" + collectionName + "/:_id";                                                        // 80
                                                                                                         // 81
    if (modifier === "insert") {                                                                         // 82
      // Post the entire new document                                                                    // 83
      addHTTPMethod("post", collectionUrl, handler);                                                     // 84
    } else if (modifier === "update") {                                                                  // 85
      // PATCH means you submit an incomplete document, to update the fields                             // 86
      // you have passed                                                                                 // 87
      addHTTPMethod("patch", itemUrl, handler, {                                                         // 88
        getArgsFromRequest: function (req) {                                                             // 89
          return [{ _id: req.params._id }, { $set: req.body }];                                          // 90
        }                                                                                                // 91
      });                                                                                                // 92
                                                                                                         // 93
      // We don't have PUT because allow/deny doesn't let you replace documents                          // 94
      // you can define it manually if you want                                                          // 95
    } else if (modifier === "remove") {                                                                  // 96
      // Can only remove a single document by the _id                                                    // 97
      addHTTPMethod("delete", itemUrl, handler, {                                                        // 98
        getArgsFromRequest: function (req) {                                                             // 99
          return [req.params._id];                                                                       // 100
        }                                                                                                // 101
      });                                                                                                // 102
    }                                                                                                    // 103
                                                                                                         // 104
    return;                                                                                              // 105
  }                                                                                                      // 106
                                                                                                         // 107
  addHTTPMethod(options.httpMethod, options.url, handler, options);                                      // 108
};                                                                                                       // 109
                                                                                                         // 110
// Monkey patch _defineMutationMethods so that we can treat them specially                               // 111
// inside Meteor.method                                                                                  // 112
var insideDefineMutationMethods = false;                                                                 // 113
var oldDMM = Mongo.Collection.prototype._defineMutationMethods;                                          // 114
Mongo.Collection.prototype._defineMutationMethods = function () {                                        // 115
  insideDefineMutationMethods = true;                                                                    // 116
  oldDMM.apply(this, arguments);                                                                         // 117
  insideDefineMutationMethods = false;                                                                   // 118
};                                                                                                       // 119
                                                                                                         // 120
Meteor.methods = Object.getPrototypeOf(Meteor.server).methods =                                          // 121
  function (methodMap) {                                                                                 // 122
    _.each(methodMap, function (handler, name) {                                                         // 123
      Meteor.method(name, handler);                                                                      // 124
    });                                                                                                  // 125
  };                                                                                                     // 126
                                                                                                         // 127
function addHTTPMethod(httpMethod, url, handler, options) {                                              // 128
  options = _.defaults(options || {}, {                                                                  // 129
    getArgsFromRequest: defaultGetArgsFromRequest                                                        // 130
  });                                                                                                    // 131
                                                                                                         // 132
  JsonRoutes.add("options", url, function (req, res) {                                                   // 133
    JsonRoutes.sendResult(res, 200);                                                                     // 134
  });                                                                                                    // 135
                                                                                                         // 136
  JsonRoutes.add(httpMethod, url, function (req, res) {                                                  // 137
    catchAndReportErrors(url, res, function () {                                                         // 138
      var userId = getUserIdFromRequest(req);                                                            // 139
                                                                                                         // 140
      // XXX replace with a real one?                                                                    // 141
      var methodInvocation = {                                                                           // 142
        userId: userId,                                                                                  // 143
        setUserId: function () {                                                                         // 144
          throw Error("setUserId not implemented in this version of simple:rest");                       // 145
        },                                                                                               // 146
        isSimulation: false,                                                                             // 147
        unblock: function () {                                                                           // 148
          // no-op                                                                                       // 149
        }                                                                                                // 150
      };                                                                                                 // 151
                                                                                                         // 152
      var handlerArgs = options.getArgsFromRequest(req);                                                 // 153
      var handlerReturn = handler.apply(methodInvocation, handlerArgs);                                  // 154
      JsonRoutes.sendResult(res, 200, handlerReturn);                                                    // 155
    });                                                                                                  // 156
  });                                                                                                    // 157
}                                                                                                        // 158
                                                                                                         // 159
function httpPublishCursor(cursor, subscription) {                                                       // 160
  _.each(cursor.fetch(), function (document) {                                                           // 161
    subscription.added(cursor._cursorDescription.collectionName,                                         // 162
      document._id, document);                                                                           // 163
  });                                                                                                    // 164
}                                                                                                        // 165
                                                                                                         // 166
function defaultGetArgsFromRequest(req) {                                                                // 167
  var args = [];                                                                                         // 168
  if (req.method === "POST") {                                                                           // 169
    // by default, the request body is an array which is the arguments                                   // 170
    args = EJSON.fromJSONValue(req.body);                                                                // 171
                                                                                                         // 172
    // If it's an object, pass the entire object as the only argument                                    // 173
    if (! _.isArray(args)) {                                                                             // 174
      args = [args];                                                                                     // 175
    }                                                                                                    // 176
  }                                                                                                      // 177
                                                                                                         // 178
  _.each(req.params, function (value, name) {                                                            // 179
    var parsed = parseInt(name, 10);                                                                     // 180
                                                                                                         // 181
    if (_.isNaN(parsed)) {                                                                               // 182
      throw new Error("REST publish doesn't support parameters whose names aren't integers.");           // 183
    }                                                                                                    // 184
                                                                                                         // 185
    args[parsed] = value;                                                                                // 186
  });                                                                                                    // 187
                                                                                                         // 188
  return args;                                                                                           // 189
}                                                                                                        // 190
                                                                                                         // 191
function hashToken(unhashedToken) {                                                                      // 192
  check(unhashedToken, String);                                                                          // 193
                                                                                                         // 194
  // The Accounts._hashStampedToken function has a questionable API where                                // 195
  // it actually takes an object of which it only uses one property, so don't                            // 196
  // give it any more properties than it needs.                                                          // 197
  var hashStampedTokenArg = { token: unhashedToken };                                                    // 198
  var hashStampedTokenReturn = Package["accounts-base"].Accounts._hashStampedToken(hashStampedTokenArg); // 199
  check(hashStampedTokenReturn, {                                                                        // 200
    hashedToken: String                                                                                  // 201
  });                                                                                                    // 202
                                                                                                         // 203
  // Accounts._hashStampedToken also returns an object, get rid of it and just                           // 204
  // get the one property we want.                                                                       // 205
  return hashStampedTokenReturn.hashedToken;                                                             // 206
}                                                                                                        // 207
                                                                                                         // 208
function getUserIdFromRequest(req) {                                                                     // 209
  if (! _.has(Package, "accounts-base")) {                                                               // 210
    return null;                                                                                         // 211
  }                                                                                                      // 212
                                                                                                         // 213
  // Looks like "Authorization: Bearer <token>"                                                          // 214
  var token = req.headers.authorization &&                                                               // 215
    req.headers.authorization.split(" ")[1];                                                             // 216
                                                                                                         // 217
  if (! token) {                                                                                         // 218
    return null;                                                                                         // 219
  }                                                                                                      // 220
                                                                                                         // 221
  // Check token expiration                                                                              // 222
  var tokenExpires = Package["accounts-base"].Accounts._tokenExpiration(token.when);                     // 223
  if (new Date() >= tokenExpires) {                                                                      // 224
    throw new Meteor.Error("token-expired", "Your login token has expired. Please log in again.");       // 225
  }                                                                                                      // 226
                                                                                                         // 227
  var user = Meteor.users.findOne({                                                                      // 228
    "services.resume.loginTokens.hashedToken": hashToken(token)                                          // 229
  });                                                                                                    // 230
                                                                                                         // 231
  if (user) {                                                                                            // 232
    return user._id;                                                                                     // 233
  } else {                                                                                               // 234
    return null;                                                                                         // 235
  }                                                                                                      // 236
}                                                                                                        // 237
                                                                                                         // 238
function catchAndReportErrors(url, res, func) {                                                          // 239
  try {                                                                                                  // 240
    return func();                                                                                       // 241
  } catch (error) {                                                                                      // 242
    var errorJson;                                                                                       // 243
    if (error instanceof Meteor.Error) {                                                                 // 244
      errorJson = {                                                                                      // 245
        error: error.error,                                                                              // 246
        reason: error.reason,                                                                            // 247
        details: error.details                                                                           // 248
      };                                                                                                 // 249
    } else if (error.sanitizedError instanceof Meteor.Error) {                                           // 250
      errorJson = {                                                                                      // 251
        error: error.sanitizedError.error,                                                               // 252
        reason: error.sanitizedError.reason,                                                             // 253
        details: error.sanitizedError.details                                                            // 254
      };                                                                                                 // 255
    } else {                                                                                             // 256
      console.log("Internal server error in " + url, error, error.stack);                                // 257
      errorJson = {                                                                                      // 258
        error: "internal-server-error",                                                                  // 259
        reason: "Internal server error"                                                                  // 260
      };                                                                                                 // 261
    }                                                                                                    // 262
                                                                                                         // 263
    var code = 500;                                                                                      // 264
    if (_.isNumber(errorJson.error)) {                                                                   // 265
      code = errorJson.error;                                                                            // 266
    }                                                                                                    // 267
                                                                                                         // 268
    JsonRoutes.sendResult(res, code, errorJson);                                                         // 269
  }                                                                                                      // 270
}                                                                                                        // 271
                                                                                                         // 272
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/simple:rest/list-api.js                                                                      //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
// publish all API methods                                                                               // 1
Meteor.publish("api-routes", function () {                                                               // 2
  var self = this;                                                                                       // 3
                                                                                                         // 4
  // Deduplicate routes across paths                                                                     // 5
  paths = {};                                                                                            // 6
                                                                                                         // 7
  _.each(JsonRoutes.routes, function (route) {                                                           // 8
    pathInfo = paths[route.path] || { methods: [], path: route.path };                                   // 9
                                                                                                         // 10
    pathInfo.methods.push(route.method);                                                                 // 11
                                                                                                         // 12
    paths[route.path] = pathInfo;                                                                        // 13
  });                                                                                                    // 14
                                                                                                         // 15
  _.each(paths, function (pathInfo, path) {                                                              // 16
    self.added("api-routes", path, pathInfo);                                                            // 17
  });                                                                                                    // 18
                                                                                                         // 19
  self.ready();                                                                                          // 20
});                                                                                                      // 21
                                                                                                         // 22
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['simple:rest'] = {};

})();

//# sourceMappingURL=simple_rest.js.map
